// Truck model
