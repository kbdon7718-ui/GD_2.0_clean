// Labour model
