// Truck controller
