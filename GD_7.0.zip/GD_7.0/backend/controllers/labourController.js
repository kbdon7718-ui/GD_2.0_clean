// Labour controller
